import { BaseEntity } from 'src/base/baseEntity'; 
import { Column, Entity, Unique } from 'typeorm'; 

@Entity() 
@Unique(['code']) 
export class Invaccpar extends BaseEntity { 
	@Column() 
	code: string; 

	@Column() 
	description: string; 

	@Column() 
	idledaccinc: number; 

	@Column() 
	idinvledacc: number; 

	@Column() 
	idexpledacc: number; 

	@Column() 
	idaccaccwitsoupurdec: number; 

	@Column() 
	idaccaccwitsounonrep: number; 

	@Column() 
	idcoscen: number; 

	@Column() 
	iddecwitcon: number; 

	@Column() 
	idnonfilwitcon: number; 

	@Column() 
	idledaccentrremdeb: number; 

	@Column() 
	identremcredelacc: number; 

	@Column() 
	idledaccdeboutrem: number; 

	@Column() 
	idoutremcreledacc: number; 

	//The next column is ENUM, please complete the code necessary  
	//@Column({ 
	//	type: 'enum', 
	//	enum: <define type enum>, 
	//	default: <define value of default type enum>, 
	//}) 
	//status: <define type enum>; 

} 
