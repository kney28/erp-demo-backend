import { BaseEntity } from 'src/base/baseEntity'; 
import { Column, Entity, Unique } from 'typeorm'; 

@Entity() 
@Unique(['code']) 
export class Invcum extends BaseEntity { 
	@Column() 
	code: string; 

	@Column() 
	filecum: number; 

	@Column() 
	actdat: Date; 

	@Column() 
	inadat: Date; 

	//The next column is ENUM, please complete the code necessary  
	//@Column({ 
	//	type: 'enum', 
	//	enum: <define type enum>, 
	//	default: <define value of default type enum>, 
	//}) 
	//status: <define type enum>; 

} 
